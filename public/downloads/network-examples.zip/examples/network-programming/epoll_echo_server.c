#define _GNU_SOURCE

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/epoll.h>
#include <sys/socket.h>
#include <unistd.h>

enum endpoint_kind
{
    ENDPOINT_LISTENER,
    ENDPOINT_CLIENT,
};

struct endpoint
{
    enum endpoint_kind kind;
};

struct connection
{
    struct endpoint base;
    int fd;
    unsigned char output[65536];
    size_t output_off;
    size_t output_len;
    bool peer_eof;
};

static int epoll_fd = -1;

static uint16_t parse_port(const char *text)
{
    char *end = NULL;
    long value = strtol(text, &end, 10);
    if (!text[0] || !end || *end != '\0' || value < 1 || value > 65535)
    {
        fprintf(stderr, "invalid port: %s\n", text);
        exit(EXIT_FAILURE);
    }
    return (uint16_t)value;
}

static int set_nonblocking(int fd)
{
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0)
    {
        return -1;
    }
    return fcntl(fd, F_SETFL, flags | O_NONBLOCK);
}

static void close_connection(struct connection *conn)
{
    fprintf(stderr, "close client fd=%d\n", conn->fd);
    epoll_ctl(epoll_fd, EPOLL_CTL_DEL, conn->fd, NULL);
    close(conn->fd);
    free(conn);
}

static int update_interest(struct connection *conn)
{
    struct epoll_event ev = {
        .data.ptr = conn,
        .events = EPOLLRDHUP,
    };

    /* Stop reading when the bounded output buffer is full: simple backpressure. */
    if (!conn->peer_eof && conn->output_len < sizeof(conn->output))
    {
        ev.events |= EPOLLIN;
    }
    if (conn->output_off < conn->output_len)
    {
        ev.events |= EPOLLOUT;
    }
    return epoll_ctl(epoll_fd, EPOLL_CTL_MOD, conn->fd, &ev);
}

static int flush_output(struct connection *conn)
{
    while (conn->output_off < conn->output_len)
    {
        ssize_t n = send(conn->fd,
                         conn->output + conn->output_off,
                         conn->output_len - conn->output_off,
                         MSG_NOSIGNAL);
        if (n > 0)
        {
            conn->output_off += (size_t)n;
            continue;
        }
        if (n < 0 && errno == EINTR)
        {
            continue;
        }
        if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK))
        {
            return 0;
        }
        return -1;
    }

    conn->output_off = 0;
    conn->output_len = 0;
    return 0;
}

static int read_input(struct connection *conn)
{
    while (!conn->peer_eof && conn->output_len < sizeof(conn->output))
    {
        size_t available = sizeof(conn->output) - conn->output_len;
        ssize_t n = recv(conn->fd, conn->output + conn->output_len, available, 0);
        if (n > 0)
        {
            conn->output_len += (size_t)n;
            continue;
        }
        if (n == 0)
        {
            conn->peer_eof = true;
            break;
        }
        if (errno == EINTR)
        {
            continue;
        }
        if (errno == EAGAIN || errno == EWOULDBLOCK)
        {
            break;
        }
        return -1;
    }
    return 0;
}

static void process_client(struct connection *conn, uint32_t events)
{
    if (events & EPOLLERR)
    {
        int error = 0;
        socklen_t len = sizeof(error);
        if (getsockopt(conn->fd, SOL_SOCKET, SO_ERROR, &error, &len) == 0 && error)
        {
            fprintf(stderr, "client fd=%d socket error: %s\n", conn->fd, strerror(error));
        }
        close_connection(conn);
        return;
    }

    if (events & (EPOLLIN | EPOLLRDHUP))
    {
        if (read_input(conn) < 0)
        {
            perror("recv");
            close_connection(conn);
            return;
        }
    }
    if (conn->output_off < conn->output_len && flush_output(conn) < 0)
    {
        perror("send");
        close_connection(conn);
        return;
    }
    if ((events & EPOLLHUP) || (conn->peer_eof && conn->output_len == 0))
    {
        close_connection(conn);
        return;
    }
    if (update_interest(conn) < 0)
    {
        perror("epoll_ctl(MOD)");
        close_connection(conn);
    }
}

static void accept_clients(int listen_fd)
{
    for (;;)
    {
        int client_fd = accept4(listen_fd, NULL, NULL, SOCK_NONBLOCK | SOCK_CLOEXEC);
        if (client_fd < 0)
        {
            if (errno == EINTR)
            {
                continue;
            }
            if (errno == EAGAIN || errno == EWOULDBLOCK)
            {
                return;
            }
            perror("accept4");
            return;
        }

        struct connection *conn = calloc(1, sizeof(*conn));
        if (!conn)
        {
            perror("calloc");
            close(client_fd);
            continue;
        }
        conn->base.kind = ENDPOINT_CLIENT;
        conn->fd = client_fd;

        struct epoll_event ev = {
            .data.ptr = conn,
            .events = EPOLLIN | EPOLLRDHUP,
        };
        if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, client_fd, &ev) < 0)
        {
            perror("epoll_ctl(ADD client)");
            close(client_fd);
            free(conn);
            continue;
        }
        fprintf(stderr, "accepted client fd=%d\n", client_fd);
    }
}

int main(int argc, char **argv)
{
    if (argc != 2)
    {
        fprintf(stderr, "usage: %s PORT\n", argv[0]);
        return EXIT_FAILURE;
    }
    uint16_t port = parse_port(argv[1]);

    int listen_fd = socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, 0);
    if (listen_fd < 0)
    {
        perror("socket");
        return EXIT_FAILURE;
    }
    if (set_nonblocking(listen_fd) < 0)
    {
        perror("fcntl(O_NONBLOCK)");
        close(listen_fd);
        return EXIT_FAILURE;
    }

    int one = 1;
    if (setsockopt(listen_fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one)) < 0)
    {
        perror("setsockopt(SO_REUSEADDR)");
        close(listen_fd);
        return EXIT_FAILURE;
    }

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = htons(port),
        .sin_addr.s_addr = htonl(INADDR_LOOPBACK),
    };
    if (bind(listen_fd, (struct sockaddr *)&addr, sizeof(addr)) < 0 || listen(listen_fd, 128) < 0)
    {
        perror("bind/listen");
        close(listen_fd);
        return EXIT_FAILURE;
    }

    epoll_fd = epoll_create1(EPOLL_CLOEXEC);
    if (epoll_fd < 0)
    {
        perror("epoll_create1");
        close(listen_fd);
        return EXIT_FAILURE;
    }

    struct endpoint listener = {.kind = ENDPOINT_LISTENER};
    struct epoll_event listen_event = {
        .data.ptr = &listener,
        .events = EPOLLIN,
    };
    if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, listen_fd, &listen_event) < 0)
    {
        perror("epoll_ctl(ADD listener)");
        close(epoll_fd);
        close(listen_fd);
        return EXIT_FAILURE;
    }

    fprintf(stderr, "epoll echo server listening on 127.0.0.1:%u\n", port);
    struct epoll_event events[64];
    for (;;)
    {
        int count = epoll_wait(epoll_fd, events, 64, -1);
        if (count < 0)
        {
            if (errno == EINTR)
            {
                continue;
            }
            perror("epoll_wait");
            break;
        }

        for (int i = 0; i < count; ++i)
        {
            struct endpoint *endpoint = events[i].data.ptr;
            if (endpoint->kind == ENDPOINT_LISTENER)
            {
                accept_clients(listen_fd);
            }
            else
            {
                process_client((struct connection *)endpoint, events[i].events);
            }
        }
    }

    close(epoll_fd);
    close(listen_fd);
    return EXIT_FAILURE;
}
