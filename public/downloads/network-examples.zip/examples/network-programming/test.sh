#!/bin/sh
set -eu

run_case() {
    program=$1
    port=$2
    expected='network-programming-regression'

    "./$program" "$port" >"/tmp/${program}.out" 2>"/tmp/${program}.log" &
    server_pid=$!
    trap 'kill "$server_pid" 2>/dev/null || true; wait "$server_pid" 2>/dev/null || true' EXIT INT TERM

    i=0
    while [ "$i" -lt 50 ]; do
        if python3 - "$port" "$expected" <<'PY'
import socket
import sys

port = int(sys.argv[1])
expected = sys.argv[2].encode()
try:
    with socket.create_connection(("127.0.0.1", port), timeout=0.2) as sock:
        sock.sendall(expected)
        received = b""
        while len(received) < len(expected):
            chunk = sock.recv(4096)
            if not chunk:
                break
            received += chunk
        if received != expected:
            raise SystemExit(1)
except OSError:
    raise SystemExit(1)
PY
        then
            kill "$server_pid" 2>/dev/null || true
            wait "$server_pid" 2>/dev/null || true
            trap - EXIT INT TERM
            echo "PASS $program"
            return 0
        fi
        i=$((i + 1))
        sleep 0.05
    done

    echo "FAIL $program" >&2
    return 1
}

run_case blocking_echo_server 19080
run_case epoll_echo_server 19081

./epoll_echo_server 19082 >/tmp/epoll-concurrency.out 2>/tmp/epoll-concurrency.log &
server_pid=$!
trap 'kill "$server_pid" 2>/dev/null || true; wait "$server_pid" 2>/dev/null || true' EXIT INT TERM
sleep 0.1

python3 - <<'PY'
import concurrent.futures
import socket


def exchange(index: int) -> None:
    unit = f"client-{index:02d}-".encode()
    payload = (unit * (32768 // len(unit) + 1))[:32768]
    with socket.create_connection(("127.0.0.1", 19082), timeout=2) as sock:
        sock.settimeout(2)
        sock.sendall(payload)
        received = bytearray()
        while len(received) < len(payload):
            chunk = sock.recv(4096)
            if not chunk:
                break
            received.extend(chunk)
        if bytes(received) != payload:
            raise RuntimeError(f"client {index}: echo mismatch")


with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
    list(pool.map(exchange, range(12)))
PY

kill "$server_pid" 2>/dev/null || true
wait "$server_pid" 2>/dev/null || true
trap - EXIT INT TERM
echo "PASS epoll_echo_server concurrency (12 clients x 32 KiB)"
