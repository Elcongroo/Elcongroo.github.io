#define _POSIX_C_SOURCE 200809L

#include <arpa/inet.h>
#include <errno.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

static volatile sig_atomic_t stop_requested;

static void on_signal(int signo)
{
    (void)signo;
    stop_requested = 1;
}

static uint16_t parse_port(const char *text)
{
    char *end = NULL;
    long value = strtol(text, &end, 10);
    if (!text[0] || !end || *end != '\0' || value < 1 || value > 65535)
    {
        fprintf(stderr, "invalid port: %s\n", text);
        exit(EXIT_FAILURE);
    }
    return (uint16_t)value;
}

static int send_all(int fd, const unsigned char *buf, size_t len)
{
    size_t off = 0;
    while (off < len)
    {
        ssize_t n = send(fd, buf + off, len - off, MSG_NOSIGNAL);
        if (n > 0)
        {
            off += (size_t)n;
            continue;
        }
        if (n < 0 && errno == EINTR)
        {
            continue;
        }
        return -1;
    }
    return 0;
}

static void serve_client(int client_fd)
{
    unsigned char buf[4096];

    for (;;)
    {
        ssize_t n = recv(client_fd, buf, sizeof(buf), 0);
        if (n > 0)
        {
            if (send_all(client_fd, buf, (size_t)n) < 0)
            {
                perror("send");
                return;
            }
            continue;
        }
        if (n == 0)
        {
            fprintf(stderr, "client fd=%d reached EOF\n", client_fd);
            return;
        }
        if (errno == EINTR)
        {
            if (stop_requested)
            {
                return;
            }
            continue;
        }
        perror("recv");
        return;
    }
}

int main(int argc, char **argv)
{
    if (argc != 2)
    {
        fprintf(stderr, "usage: %s PORT\n", argv[0]);
        return EXIT_FAILURE;
    }

    uint16_t port = parse_port(argv[1]);
    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);

    int listen_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (listen_fd < 0)
    {
        perror("socket");
        return EXIT_FAILURE;
    }

    int one = 1;
    if (setsockopt(listen_fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one)) < 0)
    {
        perror("setsockopt(SO_REUSEADDR)");
        close(listen_fd);
        return EXIT_FAILURE;
    }

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = htons(port),
        .sin_addr.s_addr = htonl(INADDR_LOOPBACK),
    };

    if (bind(listen_fd, (struct sockaddr *)&addr, sizeof(addr)) < 0)
    {
        perror("bind");
        close(listen_fd);
        return EXIT_FAILURE;
    }
    if (listen(listen_fd, 128) < 0)
    {
        perror("listen");
        close(listen_fd);
        return EXIT_FAILURE;
    }

    fprintf(stderr, "blocking echo server listening on 127.0.0.1:%u\n", port);
    while (!stop_requested)
    {
        int client_fd = accept(listen_fd, NULL, NULL);
        if (client_fd < 0)
        {
            if (errno == EINTR)
            {
                continue;
            }
            perror("accept");
            break;
        }

        fprintf(stderr, "accepted client fd=%d\n", client_fd);
        serve_client(client_fd);
        close(client_fd);
    }

    close(listen_fd);
    return EXIT_SUCCESS;
}
