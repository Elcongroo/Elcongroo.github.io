#!/usr/bin/env bash
set -u

if [[ $# -ne 1 ]]; then
    echo "Usage: $0 NEW_OUTPUT_DIRECTORY" >&2
    exit 2
fi

output_dir=$1

if [[ -e "$output_dir" ]]; then
    echo "Refusing to reuse existing path: $output_dir" >&2
    echo "Choose a new directory so old and new evidence cannot be mixed." >&2
    exit 2
fi

mkdir -p "$output_dir/interfaces"

run_capture() {
    local output_file=$1
    shift
    {
        printf '$'
        printf ' %q' "$@"
        printf '\n\n'
        "$@"
    } >"$output_dir/$output_file" 2>&1 || true
}

capture_xfrm_state_redacted() {
    {
        printf '$ ip -s xfrm state\n\n'
        ip -s xfrm state 2>&1 \
            | awk '
                /^[[:space:]]*(auth|auth-trunc|enc|aead)[[:space:]]/ {
                    for (i = 1; i <= NF; i++) {
                        if ($i ~ /^0x[[:xdigit:]]+$/ && length($i) > 10) {
                            $i = "<redacted-key>"
                        }
                    }
                    print
                    next
                }
                { print }
            '
    } >"$output_dir/50-xfrm-state-redacted.txt" || true
}

{
    printf 'captured_at_utc='
    date --utc --iso-8601=seconds
    printf 'captured_at_local='
    date --iso-8601=seconds
    printf 'user='
    id
    printf 'hostname='
    hostname
    printf 'kernel='
    uname -a
} >"$output_dir/00-meta.txt" 2>&1

run_capture 10-link-brief.txt ip -br link
run_capture 11-address-brief.txt ip -br address
run_capture 12-link-stats.txt ip -s link
run_capture 20-routes-all.txt ip route show table all
run_capture 21-rules.txt ip rule show
run_capture 30-sockets-summary.txt ss -s
run_capture 31-sockets-listening.txt ss -lntup
run_capture 40-nft-ruleset.txt nft list ruleset
run_capture 41-conntrack-stats.txt conntrack -S
capture_xfrm_state_redacted
run_capture 51-xfrm-policy.txt ip -s xfrm policy
run_capture 52-xfrm-stat.txt cat /proc/net/xfrm_stat
run_capture 60-interrupts.txt cat /proc/interrupts
run_capture 61-softirqs.txt cat /proc/softirqs
run_capture 62-softnet-stat.txt cat /proc/net/softnet_stat
run_capture 70-nstat.txt nstat -az

while IFS= read -r interface_name; do
    [[ -n "$interface_name" ]] || continue
    [[ "$interface_name" == "lo" ]] && continue

    safe_name=${interface_name//[^[:alnum:]_.-]/_}
    run_capture "interfaces/${safe_name}-driver.txt" ethtool -i "$interface_name"
    run_capture "interfaces/${safe_name}-channels.txt" ethtool -l "$interface_name"
    run_capture "interfaces/${safe_name}-features.txt" ethtool -k "$interface_name"
    run_capture "interfaces/${safe_name}-stats.txt" ethtool -S "$interface_name"

    queue_root="/sys/class/net/$interface_name/queues"
    if [[ -d "$queue_root" ]]; then
        {
            printf 'queue_root=%s\n\n' "$queue_root"
            find "$queue_root" -maxdepth 2 -type f \
                \( -name rps_cpus -o -name rps_flow_cnt -o -name xps_cpus \) \
                -print -exec sh -c 'printf "value="; cat "$1"' sh '{}' \;
        } >"$output_dir/interfaces/${safe_name}-queue-maps.txt" 2>&1 || true
    fi
done < <(ip -o link show 2>/dev/null | awk -F': ' '{print $2}' | cut -d'@' -f1)

(
    cd "$output_dir" || exit 1
    find . -type f ! -name SHA256SUMS.txt -print0 \
        | sort -z \
        | xargs -0 sha256sum
) >"$output_dir/SHA256SUMS.txt"

printf 'Snapshot saved to %s\n' "$output_dir"
printf 'Review and sanitize network details before sharing or committing it.\n'
