# Linux内核网络路径只读快照

这个目录提供一个只读快照脚本，用于在VPN测试前后保存Linux网络状态，帮助回答：包有没有进入接口、路由怎样选择、Socket是否存在、Netfilter/XFRM状态是否安装、软中断和驱动统计是否变化。

脚本不会修改接口、路由、防火墙、Namespace、XFRM或内核参数，也不会自动使用`sudo`。

## 先手工执行关键命令

第一次不要直接运行脚本。先逐条理解：

```bash
uname -a
ip -br link
ip -br address
ip -s link
ip route show table all
ip rule show
ss -s
nstat -az
ip -s xfrm state  # 只在本地核对；原始输出可能包含会话密钥
ip -s xfrm policy
cat /proc/softirqs
cat /proc/net/softnet_stat
cat /proc/net/xfrm_stat
```

- `ip -s link`：看接口包数、字节数、drop与error；
- `ip route`和`ip rule`：看普通路由与策略路由；
- `ss -s`：看Socket总体状态；
- `nstat -az`：看IP/TCP/UDP/XFRM等协议统计；
- `ip -s xfrm`：看IPsec State/Policy和包字节计数；其中State通常会显示ESP会话密钥，不能直接截图、提交或外发；
- `/proc/softirqs`、`softnet_stat`：看CPU网络处理；
- `/proc/net/xfrm_stat`：看XFRM错误类别。

某条命令不存在或权限不足时，脚本会把错误原样保存在对应文件中并继续收集其他信息。

## 自动保存一次快照

```bash
cd examples/linux-kernel-network-path
./inspect_kernel_network.sh /tmp/kernel-net-before
```

第一个参数是输出目录。必须使用一个不存在的新目录，防止旧数据与新数据混在一起。

复现实验或压测后再采集一次：

```bash
./inspect_kernel_network.sh /tmp/kernel-net-after
```

比较：

```bash
diff -ru /tmp/kernel-net-before /tmp/kernel-net-after
```

时间戳、累计计数和临时Socket天然会变化。重点是把差值与同一次明确的测试流量对应起来。

## 输出说明

脚本会生成：

- `00-meta.txt`：采集时间、内核和用户身份；
- `10-link-brief.txt`、`11-address-brief.txt`、`12-link-stats.txt`：接口状态；
- `20-routes-all.txt`、`21-rules.txt`：路由与策略路由；
- `30-sockets-summary.txt`、`31-sockets-listening.txt`：Socket状态；
- `40-nft-ruleset.txt`、`41-conntrack-stats.txt`：Netfilter与Conntrack；
- `50-xfrm-state-redacted.txt`、`51-xfrm-policy.txt`、`52-xfrm-stat.txt`：IPsec数据面；State中的认证/加密密钥会在写盘前替换为`<redacted-key>`；
- `60-interrupts.txt`、`61-softirqs.txt`、`62-softnet-stat.txt`：CPU与软中断；
- `70-nstat.txt`：协议统计；
- `interfaces/`：每个非loopback接口的驱动、队列、offload和统计；
- `SHA256SUMS.txt`：本次原始快照文件哈希。

## 安全边界

输出可能包含内网地址、接口名、防火墙规则、隧道端点和网络拓扑。提交到Git、发送给外部人员或粘贴到AI服务前必须脱敏，并遵守公司的源码和数据分级要求。脚本会主动遮蔽常见XFRM密钥字段，但这只是降低误泄漏风险，不能代替人工检查。

快照只能说明采集时刻的系统状态。它不替代PCAP、应用日志、源码版本、构建产物身份、负面测试和对端证据。
